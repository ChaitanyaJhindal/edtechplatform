function togglePasswordVisibility() {
    const passwordInput = document.getElementById('password');
    const eyeIcon = document.querySelector('.fa-eye');
    if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      eyeIcon.classList.add('fa-eye-slash');
      eyeIcon.classList.remove('fa-eye');
    } else {
      passwordInput.type = 'password';
      eyeIcon.classList.add('fa-eye');
      eyeIcon.classList.remove('fa-eye-slash');
    }
  }
  
  function login() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    fetch('/users.json')
      .then((response) => response.json())
      .then((users) => {
        const user = users.find(
          (user) => user.email === email && user.password === password
        );
        if (user) {
          window.location.href = '/homepage';
        } else {
          alert('Invalid email or password.');
        }
      })
      .catch((error) => console.error('Error loading JSON:', error));
  }